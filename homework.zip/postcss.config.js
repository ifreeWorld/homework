module.exports = {
  plugins: {
    'postcss-flexbugs-fixes': {}
  }
}
